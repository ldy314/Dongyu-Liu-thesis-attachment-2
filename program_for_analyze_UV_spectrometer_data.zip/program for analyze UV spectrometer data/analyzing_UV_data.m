%*************************************
%Dongyu Liu created on 2015.07.29
%dongyu.liu@tufts.edu
%liuzx314@gmail.com
% skype: dongyu.liu1
% this prgram is designed for analyzing the batch data from our UV spectrometer
%൶�Զ��֮�˺�Ϊ������

%example of input

%foldername='C:\Users\dliu03\Google Drive\project\Research Project\MFRP & mars chamber\mars chamber\program for analyze UV spectrometer data'
%filename='UV spectra-modified.xlsx';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
foldername='F:\g drive\project\Research Project\MFRP_mars chamber\20180719';
% this is folder where the file is kept.
filename='20180719 1g of 0.1gNaClO3+0.5gTiO2+10g sand, 450w uv, no filter, MARS condition, 48h-1 min.EP1x.xlsx';% this is the modified data file name, which should be an excel file
title_for_graph='20180719 1g of 0.1gNaClO3+0.5gTiO2+10g sand, 450w uv, no filter, MARS condition, 48h-1 min';
%only need to change these two parameters.

pathway=strcat(foldername,'\',filename);
[num,txt,raw] = xlsread(pathway);
%input the data file
sizeof_file=size(num);
scannumber=(1:sizeof_file(2)-1);
wavelength=num(:,1);% this is the wavelength measured in this experiment
count=2;
dataset=num(:,2:sizeof_file(2));% dataset only contain intensity,

X=repmat(wavelength,1,sizeof_file(2)-1);% X is the axis of wavelength
Y=repmat(scannumber,sizeof_file(1),1);% X is the axis of scan number

mesh(X,Y,dataset);
title(title_for_graph);

xlabel('wavelength'),ylabel('scan number'),zlabel('intensity');
savefig_name=strcat(foldername,'\',title_for_graph,'3D plot.fig');
savefig(savefig_name);
colorbar;
set(gca, 'zscale', 'log');


name_for_three_D_semilog = strcat(foldername,'\',title_for_graph,'processed UV semilog graph.fig');
txt1 = strcat(pathway,'semilog 3D plot.fig');
savefig(name_for_three_D_semilog );

%sum_of_intenisty_at_each_wavelength=;
sum_intensity_wavelength=sum(dataset,2);
save_varible=strcat(foldername,'\processed UV data sum_intensity_wavelength.mat');
save(save_varible,'dataset');
i=0;

